$(document).ready(function () {
$('#be').qtip({content: {title:'Belgique',text:'001 Avis / Moyenne des évaluations : 4,00'},style:{classes:'qtip-tipsy qtip-shadow',tip:{corner:false}}})
$('#de').qtip({content: {title:'Allemagne',text:'001 Avis / Moyenne des évaluations : 5,00'},style:{classes:'qtip-tipsy qtip-shadow',tip:{corner:false}}})
$('#gb').qtip({content: {title:'Royaume-Uni',text:'002 Avis / Moyenne des évaluations : 5,00'},style:{classes:'qtip-tipsy qtip-shadow',tip:{corner:false}}})
});
